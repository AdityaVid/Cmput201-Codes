avaidya1@ug10:~/Documents/Cmput201/labs/lab01_sol>emacs ls_com.txt
avaidya1@ug10:~/Documents/Cmput201/labs/lab01_sol>ls -h -s -l ~ >ls_out.txt
avaidya1@ug10:~/Documents/Cmput201/labs/lab01_sol>gcc -Wall -std=c99 hello.c -o hello
avaidya1@ug10:~/Documents/Cmput201/labs/lab01_sol>./hello
avaidya1@ug10:~/Documents/Cmput201/labs/lab01_sol>tar -cf sumbit.tar check ls_com.txt ls_out.txt hello.c readme.txt 
